from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time

import pandas as pd

import warnings
warnings.filterwarnings('ignore')


options = webdriver.ChromeOptions()
options.add_argument('--on-sandbox') # 보안기능 샌드박스 비활성화
options.add_argument('--disable-dev-shm-usage') # dev/shm 디렉토리 사용 안함


service = ChromeService(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

driver.set_window_size(800, 800)

driver.get('https://www.skyscanner.co.kr/transport/flights/sela/jfuk/240830/?adultsv2=1&cabinclass=economy&childrenv2=&ref=home&rtn=0&preferdirects=true&outboundaltsenabled=false&inboundaltsenabled=false')


time.sleep(10)
driver.execute_script('window.scrollTo(0,800)')
time.sleep(5)