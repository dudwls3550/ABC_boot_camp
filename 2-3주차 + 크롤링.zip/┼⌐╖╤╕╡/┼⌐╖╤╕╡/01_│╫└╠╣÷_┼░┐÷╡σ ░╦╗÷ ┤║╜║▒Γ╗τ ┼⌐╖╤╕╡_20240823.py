'''
네이버 뉴스 키워드를 검색을 통한 뉴스 데이터 수집 후 csv 파일 저장하기
1) 데이터 프레임 생성 (수집한 정보 설정), 2) 뉴스 검색 및 데이터 수집 3) 수집한 데이터 csv 파일로 저장
'''

from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from bs4 import BeautifulSoup

import re

from pytz import timezone
import datetime

import time

import pandas as pd

import warnings 
warnings.filterwarnings("ignore")

options = webdriver.ChromeOptions()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

service = ChromeService(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)


# 1) 데이터 프레임 생성
data = pd.DataFrame(columns=['뉴스제목', '언론사','요약', '뉴스링크', '개시일', '수집일자'])
title_list =[]
journal_list =[]
author_list =[]
summary_list =[]
link_list =[]


# 2) 뉴스 검색 주제 조합하여 뉴스 데이터 수집

# 2-1) 뉴스 검색 키워드 설정
keyword_txt ='LAM 모델'
print(keyword_txt, '검색')  

## 2-2) 뉴스 검색 사이트 접속
search_url = 'https://search.naver.com/search.naver?sm=tab_hty.top&where=news'
driver.get(search_url)

SCROLL_PAUSE_TIME = 3
SCROLL_MAX_COUNT = 1

time.sleep(SCROLL_PAUSE_TIME)

# 검색창 element 찾기 / 검색창 input name = query
keyword = driver.find_element(By.NAME, "query")
keyword.send_keys(keyword_txt)

# 입력한 값 전송
keyword.send_keys(Keys.RETURN)


driver.implicitly_wait(SCROLL_PAUSE_TIME) # 화면 렌더링 기다리기

driver.execute_script("window.scrollTo(0,800)")
time.sleep(SCROLL_PAUSE_TIME)

# 3) 스크롤 내리기
last_height = driver.execute_script('return document.body.scrollHeight')
scroll = 0

print('3.스크롤 중.....' + keyword_txt)
while True:

    driver.execute_script('window.scrollTo(0,document.body.scrollHeight);')
    time.sleep(SCROLL_PAUSE_TIME)
    
    new_height = driver.execute_script('return document.body.scrollHeight')
    
    if new_height == last_height:
        break
    
    elif scroll > SCROLL_MAX_COUNT:
        break
    
    last_height = new_height
    time.sleep(SCROLL_PAUSE_TIME)
    
    scroll = scroll + 1


#info 
# 4) 뉴스 정보 크롤링    
html_source = driver.page_source
soup = BeautifulSoup(html_source, 'html.parser')

# 뉴스 기사를 감싼 li 찾기 <li class="bx" id="sp_nws1">
li = soup.find_all('li', {'class', 'bx'})   
print('뉴스 개수', len(li))


press_list =[]
date_list =[]
title_list =[]
summary_list =[]
link_list =[]
time_list = []


# data = pd.DataFrame(columns=['뉴스제목', '언론사','요약', '뉴스링크', '개시일', '수집일자'])
for i in li:
    
    try:
    
        # 언론사
        press = i.find('a', {'class', 'info press'}).text
        print(press)
        press_list.append(press)
    
        # 개시일
        new_date = i.find('span', {'class', 'info'}).text
        print(new_date)
        date_list.append(new_date)
    
        # 뉴스제목
        title = i.find('a', {'class', 'news_tit'})['title']
        # html 태그 삭제하기
        cleanr = re.compile('<.*?>') # html 태그 정규식
        title = re.sub(cleanr, '', title) # html 지우기
        print(title)
        title_list.append(title)
    
        # 요약
        summary = i.find('a', {'class', 'api_txt_lines dsc_txt_wrap'}).text
        print(summary)
        summary_list.append(summary)
    
        # 뉴스 링크
        link =  i.find('a', {'class', 'news_tit'})['href']
        link_list.append(link)
        
        # 수집 일자
        time_list.append(datetime.datetime.now(timezone('Asia/Seoul')).strftime('%Y-%m-%d %H:%M:%S'))
    
    except:
        pass    

# data = pd.DataFrame(columns=['뉴스제목', '언론사','요약', '뉴스링크', '개시일', '수집일자'])    
        
news_dic = {'뉴스제목' : title_list, '언론사' : press_list, '요약': summary_list, '뉴스링크':link_list, '개시일': date_list, '수집일자' : time_list}
news_df = pd.DataFrame(news_dic)        
        
print('——————————————————————————————————————————————')

# 5-1) 수집된 데이터 확인하기
print(news_df.info())

# 5-2) 수집 날짜 설정
crwaling_date = datetime.datetime.now(timezone('Asia/Seoul')).strftime('%Y%m%d')     

# 5-3) csv 파일로 수집한 논문 데이터 저장
news_df.to_csv(f'{keyword_txt}_뉴스_크롤링_{crwaling_date}.csv', encoding='utf-8-sig', index=False)

print('==' * 30)
print('파일 저장 완료….')

# 브라우저 닫기
driver.close()
