'''
수집한 데이터를 활용한 단어 빈도 수 워드 클라우드 시각화
1) 데이터 준비하기 2) 텍스트 뭉치 만들기 3) 단어 추출하기 4) 불용어 처리하기 
5) 워드클라우드 Mask 설정하기  6) 워드클라우드 시각화 
7) 워드클라우드 이미지 저장하기 (.png)
'''

import pandas as pd
import re
import numpy as np

import matplotlib.pyplot as plt
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator


# 불용어 리스트
stopwords = ['은', '는', '이', '가', '으로', '에', '그', '어', 'a', 'the', 'an', 'i', '및', '위한', '[', ']', '(', ')','과']

def remove_stopwords(words):
  return " ".join([word for word in words if word not in stopwords])


# 1) 데이터 준비하기
news_pd = pd.read_csv('mz세대_뉴스_크롤링_20240819.csv')
print(news_pd['뉴스제목'][0])

# 2) 워드클라우드 텍스트 만들기
text = " ".join(paper for paper in news_pd['뉴스제목'].astype(str))

# 단어 추출 하기 (영어, 한국어 추출)
# 3) 단어 추출
# 가사 뭉치에서 단어를 추출하고, 단어의 빈도를 계산
# \b는 word boundary 단어의 시작과 끝에 있는 문자로 매칭
# \w는 word의 약자로 알파벳, 숫자, _ 문자를 찾기 [0-9Aa-Zzㄱ-ㅎ]
words = re.findall(r'\b\w+\b', text.lower())

# 4) 불용어 처리
words = remove_stopwords(words)
print(words)

# 5) 워드클라우드 Mask 설정하기 
icon = Image.open('mz.png')    # 마스크가 될 이미지 불러오기 
plt.imshow(icon)

harry_mask = np.array(icon)

# 6) 워드클라우드 시각화 
font_path = 'YangJuByeolsan.otf'
plt.subplots(figsize=(25,15))
wordcloud = WordCloud(background_color='black', width=1000, height=700, font_path=font_path, 
                      mask=harry_mask, stopwords=STOPWORDS).generate(words)

plt.axis("off")
image_colors = ImageColorGenerator(harry_mask)
wordcloud = wordcloud.recolor(color_func=image_colors)

plt.imshow(wordcloud, interpolation='bilinear')

# 7) 워드클라우드 이미지 저장하기 (.png)
wordcloud.to_file(filename="mz_wordcloud.png") # to_file 함수
print('이미지 저장 완료...')

